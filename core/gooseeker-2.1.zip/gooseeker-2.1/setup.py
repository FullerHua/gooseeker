# -*- coding: utf-8 -*-

from distutils.core import setup

setup(
    name='gooseeker',
    version='2.1',
    py_modules=['gooseeker']
 )